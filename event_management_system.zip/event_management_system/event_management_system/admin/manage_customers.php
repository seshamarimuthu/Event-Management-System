<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $user_id = $_POST['delete_id'];
    $conn->query("DELETE FROM bookings WHERE user_id = '$user_id'");
    $conn->query("DELETE FROM users WHERE id = '$user_id'");

    header("Location: manage_customers.php");
    exit();
}

$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Customers</title>
    <link rel="stylesheet" href="../styles/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin.php">Home</a>
                <a href="manage_bookings.php">Manage Bookings</a>
                <a href="manage_customers.php" class="active">Manage Customers</a>
                <a href="add_event.php">Add Event</a>
                <a href="manage_events.php">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <h1>Manage Customers</h1>
            <table class="event-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Delete this user? This will also remove their bookings.')">
                                    <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </main>
    </div>

    <script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>
</body>
</html>
