<?php
session_start();
include '../db.php';


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

$sql = "SELECT e.*, c.name AS category_name, v.name AS venue_name 
        FROM events e 
        LEFT JOIN categories c ON e.category_id = c.id
        LEFT JOIN venues v ON e.venue_id = v.id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Events</title>
    <link rel="stylesheet"  href="../styles/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
            <a href="admin.php">Home</a>
                <a href="manage_bookings.php">Manage Bookings</a>
                <a href="manage_customers.php">Manage Customers</a>
                <a href="add_event.php">Add Event</a>
                <a href="manage_events.php" class="active">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <h1>Manage Events</h1>
            <table class="event-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Venue</th>
                        <th>Category</th>
                        <th>Slots</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td><?= htmlspecialchars($row['venue_name']) ?></td>
                            <td><?= htmlspecialchars($row['category_name']) ?></td>
                            <td><?= htmlspecialchars($row['slots']) ?></td>
                            <td>
                                <a class="edit-btn" href="edit_event.php?id=<?= $row['id'] ?>">Edit</a> | 
                                <a class="delete-btn" href="delete_event.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this event?')">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
<script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>