<?php
session_start();
include '../db.php';
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['usertype'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../styles/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <a href="admin.php">Home</a>
                <a href="manage_bookings.php">Manage Bookings</a>
                <a href="manage_customers.php">Manage Customers</a>
                <a href="add_event.php">Add Event</a>
                <a href="manage_events.php">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>
        <main class="main-content">
            <h1>Welcome, <?=$_SESSION['username']?></h1>
            <p>Select an option from the menu to get started.</p>
        </main>
    </div>

    <script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>
</body>
</html>
