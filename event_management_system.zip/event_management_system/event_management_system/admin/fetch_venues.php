<?php
include '../db.php';

$query = "SELECT * FROM venues";
$result = $conn->query($query);

$venues = [];
while ($row = $result->fetch_assoc()) {
    $venues[] = ["id" => $row["id"], "name" => $row["name"]];
}

echo json_encode($venues);
?>
