<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $description = $_POST["description"];
    $slots = $_POST["slots"];
    $price = $_POST["price"];
    $available_time = $_POST["available_time"];
    $available_date = $_POST["available_date"];
    $venue_id = $_POST["venue"];
    $category_id = $_POST["category"];

    $sql = "INSERT INTO events (name, description, slots, price, available_time, available_date, venue_id, category_id) 
            VALUES ('$name', '$description', '$slots', '$price', '$available_time', '$available_date', '$venue_id', '$category_id')";

    if ($conn->query($sql) === TRUE) {
        header("Location: manage_events.php");
        exit();
    } else {
        echo "<p class='err'>Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Event</title>
    <link rel="stylesheet"  href="../styles/admin.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        .main-content {
            padding: 0px;
        }
        .input, input, select, textarea {
            width: 80%;
            padding: 8px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .signup-btn {
            padding: 10px;
            border-radius: 5px;
            background-color: #00a400;
            color: white;
            border: none;
            width: 83%;
            font-size: 16px;
            cursor: pointer;
        }

        .signup-btn:hover {
            background-color: #008a00;
        }

        h1 {
            color: #1877f2;
            margin-bottom: 20px;
            text-align: center;
        }

        .err {
            color: red;
            text-align: center;
        }

        body {
            background-color: #f2f4f7;
        }

        form {
            max-width: 500px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
            <a href="admin.php">Home</a>
                <a href="manage_bookings.php">Manage Bookings</a>
                <a href="manage_customers.php">Manage Customers</a>
                <a href="add_event.php" class="active">Add Event</a>
                <a href="manage_events.php">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <!-- <div class="box"> -->
                <h1>Add Event</h1>
                <form method="POST">
                    <input type="text" name="name" placeholder="Event Name" required class="input">
                    <textarea name="description" placeholder="Description" class="input"></textarea>
                    <input type="number" name="slots" placeholder="Available Slots" required class="input">
                    <input type="text" name="price" placeholder="Price" required class="input">
                    <input type="time" name="available_time" required class="input">
                    <input type="date" name="available_date" required class="input">

                    <select name="venue" id="venue_select" required class="input" style="width:83%;">
                        <option value="">Select Venue</option>
                    </select>

                    <select name="category" id="category_select" required class="input" style="width:83%;">
                        <option value="">Select Category</option>
                    </select>

                    <button type="submit" class="signup-btn">Add Event</button>
                </form>
            <!-- </div> -->
        </main>
    </div>

    <script>
    $(document).ready(function(){
        function loadCategories() {
            $.ajax({
                url: "fetch_categories.php",
                type: "GET",
                dataType: "json",
                success: function(data) {
                    let categoryDropdown = $("#category_select");
                    categoryDropdown.html('<option value="">Select Category</option>');
                    $.each(data, function(index, category) {
                        categoryDropdown.append(`<option value="${category.id}">${category.name}</option>`);
                    });
                }
            });
        }

        function loadVenues() {
            $.ajax({
                url: "fetch_venues.php",
                type: "GET",
                dataType: "json",
                success: function(data) {
                    let venueDropdown = $("#venue_select");
                    venueDropdown.html('<option value="">Select Venue</option>');
                    $.each(data, function(index, venue) {
                        venueDropdown.append(`<option value="${venue.id}">${venue.name}</option>`);
                    });
                }
            });
        }

        loadCategories();
        loadVenues();
    });
    </script>
</body>
</html>
<script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>


