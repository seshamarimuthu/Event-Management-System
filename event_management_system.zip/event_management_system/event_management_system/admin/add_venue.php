<?php
session_start();
include '../db.php';


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $venue_name = $_POST["venue_name"];

    $check_sql = "SELECT * FROM venues WHERE name = '$venue_name'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        $message = "Venue already exists!";
    } else {
        $sql = "INSERT INTO venues (name) VALUES ('$venue_name')";
        if ($conn->query($sql) === TRUE) {
            $message = "Venue added successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Venue</title>
    <link rel="stylesheet"  href="../styles/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
            <a href="admin.php">Home</a>
                <a href="manage_bookings.php">Manage Bookings</a>
                <a href="manage_customers.php">Manage Customers</a>
                <a href="add_event.php">Add Event</a>
                <a href="manage_events.php">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php" class="active">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <h1>Add Venue</h1>
            <?php if (!empty($message)) echo "<p style='margin-bottom: 15px; color: #c0392b;'>$message</p>"; ?>
            <form method="POST">
                <input type="text" name="venue_name" placeholder="Venue Name" required style="padding: 10px; width: 300px; margin-bottom: 10px;">
                <br>
                <button type="submit" class="edit-btn">Add Venue</button>
            </form>
        </main>
    </div>
</body>
</html>
<script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>