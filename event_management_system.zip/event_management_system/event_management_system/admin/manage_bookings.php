<?php
session_start();
include '../db.php';


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

$sql = "SELECT bookings.id, users.name AS customer_name, events.name AS event_name, events.slots, bookings.status 
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN events ON bookings.event_id = events.id";
$result = $conn->query($sql);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $booking_id = $_POST['delete_id'];
    $conn->query("DELETE FROM bookings WHERE id = '$booking_id'");
    header("Location: manage_bookings.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Bookings</title>
    <link rel="stylesheet"  href="../styles/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
            <a href="admin.php">Home</a>
                <a href="manage_bookings.php" class="active">Manage Bookings</a>
                <a href="manage_customers.php">Manage Customers</a>
                <a href="add_event.php">Add Event</a>
                <a href="manage_events.php">Manage Events</a>
                <a href="add_category.php">Add Category</a>
                <a href="add_venue.php">Add Venue</a>
                <a href="../logout.php" class="logout">Logout</a>
            </nav>
        </aside>

        <main class="main-content">
            <h1>Manage Bookings</h1>
            <table class="event-table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Event</th>
                        <!-- <th>Slots</th> -->
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['customer_name']) ?></td>
                            <td><?= htmlspecialchars($row['event_name']) ?></td>
                            <!-- <td><?php //htmlspecialchars($row['slots']) ?></td> -->
                            <td><?= htmlspecialchars($row['status']) ?></td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Delete this booking?')">
                                    <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
<script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>