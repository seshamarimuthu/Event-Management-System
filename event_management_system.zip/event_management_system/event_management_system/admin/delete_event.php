<?php
include '../db.php';

if (isset($_GET['id'])) {
    $event_id = $_GET['id'];
    $conn->query("DELETE FROM bookings WHERE event_id = '$event_id'");
    $delete_sql = "DELETE FROM events WHERE id = '$event_id'";

    if ($conn->query($delete_sql) === TRUE) {
        header("Location: manage_events.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}

?>
