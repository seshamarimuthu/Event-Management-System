<?php
session_start();
include '../db.php'; 
require '../phpmailer/src/PHPMailer.php';  
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';
require_once '../razorpay-php/Razorpay.php';  

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Razorpay\Api\Api;

if ($_SESSION['usertype'] !== 'customer') {
    header("Location: index.php");
    exit;
}

$mailerEmail = 'seshadhoni777@gmail.com'; 
$mailerPassword = 'dgxa xfvu sdzh hulv';   
$mailerName = 'sesha';

$user_id = $_SESSION["user_id"];
$event_id = $_GET["id"] ?? 0;
$qty = isset($_GET['qty']) ? (int)$_GET['qty'] : 1;

if ($qty < 1) {
    echo "<script>alert('Invalid ticket quantity.');window.location.href='book_ticket.php';</script>";
    exit;
}

$event_sql = "SELECT * FROM events WHERE id = $event_id";
$event_result = $conn->query($event_sql);

if (!$event_result || $event_result->num_rows == 0) {
    echo "<script>alert('Event not found.');window.location.href='book_ticket.php';</script>";
    exit;
}

$event = $event_result->fetch_assoc();

if ($event['slots'] < $qty) {
    echo "<script>alert('No slots are currently available.');window.location.href='book_ticket.php';</script>";
    exit;
}

$total_amount = $event['price'] * $qty;
$razorpay_amount = $total_amount * 100; 

$user_result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $user_result->fetch_assoc();
$user_email = $user['email'];

$razorpayApiKey = 'rzp_test_ZSEAuP3Q29FzZq';  
$razorpaySecret = 'jhuHUarLsN6dT9uuTQEG7tpG'; 

$api = new Api($razorpayApiKey, $razorpaySecret);

$orderData = [
    'receipt' => $user_id . '-' . $event_id,
    'amount' => $razorpay_amount,
    'currency' => 'INR',
    'payment_capture' => 1,
];

try {
    $razorpayOrder = $api->order->create($orderData);
    $orderId = $razorpayOrder->id; 
} catch (Exception $e) {
    die("Error creating Razorpay order: " . $e->getMessage());
}

$new_slots = $event['slots'] - $qty;
$conn->query("UPDATE events SET slots = $new_slots WHERE id = $event_id");

$conn->query("INSERT INTO bookings (user_id, event_id, quantity, status, payment_status, order_id) 
              VALUES ('$user_id', '$event_id', '$qty', 'confirmed', 'pending', '$orderId')");

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $mailerEmail; 
    $mail->Password = $mailerPassword;   
    $mail->SMTPSecure = 'tls';   
    $mail->Port = 587;       
    $mail->setFrom($mailerEmail, $mailerName);
    $mail->addAddress($user_email);  
    $mail->isHTML(true);
    $mail->Subject = "Booking Confirmed for " . $event['name'];
    $mail->Body = "
        <h2>Booking Confirmed!</h2>
        <p>Thank you for booking <strong>{$event['name']}</strong></p>
        <p>Description: {$event['description']}</p>
        <p>Date: {$event['available_date']}</p>
        <p>Time: {$event['available_time']}</p>
        <p>Quantity: <strong>{$qty}</strong></p>
        <p>Price per ticket: ₹{$event['price']}</p>
        <p><strong>Total: ₹{$total_amount}</strong></p>
        <p>Status: <strong>Confirmed</strong></p>
        <p>Your order ID is: $orderId</p>
    ";
    $mail->send();

    echo "
    <script src='https://checkout.razorpay.com/v1/checkout.js'></script>
    <script>
        var options = {
            key: '{$razorpayApiKey}',
            amount: $razorpay_amount,
            currency: 'INR',
            order_id: '$orderId',
            name: 'Event Booking',
            description: 'Booking for {$event['name']}',
            handler: function (response) {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'verify_payment.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        if (xhr.responseText === 'Payment Verified Successfully') {
                            window.location.href = 'payment_success.php?order_id=' + response.razorpay_order_id;
                        } else {
                            alert('Payment verification failed!');
                            window.location.href = 'book_ticket.php';
                        }
                    }
                };
                var data = 'payment_id=' + response.razorpay_payment_id + 
                           '&order_id=' + response.razorpay_order_id + 
                           '&signature=' + response.razorpay_signature;
                xhr.send(data);
            },
            prefill: {
                name: '{$user['name']}',
                email: '{$user['email']}'
            },
            theme: {
                color: '#F37254'
            },
            modal: {
                ondismiss: function() {
                    window.location.href = 'book_ticket.php';
                }
            }
        };
        var rzp = new Razorpay(options);
        rzp.open();
    </script>";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
?>
