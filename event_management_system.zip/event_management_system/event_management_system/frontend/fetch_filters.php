<?php
include '../db.php';

$response = [
    'categories' => [],
    'venues' => []
];

$category_query = "SELECT id, name FROM categories ORDER BY name ASC";
$category_result = $conn->query($category_query);
while ($row = $category_result->fetch_assoc()) {
    $response['categories'][] = $row;
}

$venue_query = "SELECT id, name FROM venues ORDER BY name ASC";
$venue_result = $conn->query($venue_query);
while ($row = $venue_result->fetch_assoc()) {
    $response['venues'][] = $row;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
