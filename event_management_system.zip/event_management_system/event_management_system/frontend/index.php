<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="2;url=../index.php">
    <title>Redirecting...</title>
    <link rel="stylesheet" href="../styles/frontend.css">
</head>
<body>
<p style="text-align: center;">You are being redirected. Please wait...</p>
    <script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
                window.location.reload();
            }
        });
    </script>
</body>
</html>
