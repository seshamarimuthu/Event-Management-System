<?php
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    echo "<h1>Payment Successful!</h1>";
    echo "<p>Your payment for Order ID: $order_id has been successfully processed.</p>";
} else {
    echo "<h1>Payment Failed!</h1>";
    echo "<p>Something went wrong. Please try again.</p>";
}
?>
