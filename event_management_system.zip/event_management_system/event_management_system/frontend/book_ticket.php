<?php
session_start();
include '../db.php';
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if ($_SESSION['usertype'] !== 'customer') {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id']; 
$booking_sql = "SELECT b.*, e.name as event_name, e.description, e.price, e.available_date, e.available_time
                FROM bookings b
                JOIN events e ON b.event_id = e.id
                WHERE b.user_id = $user_id";
$booking_result = $conn->query($booking_sql);
$bookings = [];

while ($row = $booking_result->fetch_assoc()) {
    $bookings[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Management</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="../styles/frontend.css">
    <style>
#booking_list {
    margin-top: 30px;
}

#booking_list table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    border: 1px solid #ddd;
}

#booking_list th, #booking_list td {
    padding: 12px;
    text-align: left;
}

#booking_list th {
    background-color: #f4f4f4;
    font-weight: bold;
    border-bottom: 2px solid #ddd;
}

#booking_list td {
    background-color: #fafafa;
    border-bottom: 1px solid #ddd;
}

#booking_list tr:hover {
    background-color: #f1f1f1;
}

#booking_list td:nth-child(5), #booking_list td:nth-child(6) {
    font-weight: bold;
    color: #333;
}

#booking_list td:nth-child(6) {
    text-transform: capitalize;
}

#booking_list td.status-pending {
    color: #ff9800;
}

#booking_list td.status-confirmed {
    color: #4caf50;
}

#booking_list td.status-cancelled {
    color: #f44336;
}

#booking_list p {
    font-style: italic;
    color: #777;
}

    </style>
</head>
<body>

<div class="container">
    <div class="top-bar">
        <h2 class="welcome-msg">Welcome, <?= htmlspecialchars($_SESSION['username']) ?></h2>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <h1>Events</h1>

    <div class="filter-container">
        <input type="text" id="event_name_search" placeholder="Search by event name">
        <select id="category_filter">
            <option value="">All Categories</option>
        </select>
        <select id="venue_filter">
            <option value="">All Venues</option>
        </select>
        <input type="date" id="date_filter">
        <input type="time" id="time_filter">
        <button id="search_btn">Search</button>
    </div>

    <div id="event_list"></div>

    <h2 style=" text-align: center;">Your Bookings</h2>
    <div id="booking_list">
        <?php if (count($bookings) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
    <?php foreach ($bookings as $booking): ?>
        <tr>
            <td><?= htmlspecialchars($booking['event_name']) ?></td>
            <td><?= htmlspecialchars($booking['description']) ?></td>
            <td><?= htmlspecialchars($booking['available_date']) ?></td>
            <td><?= htmlspecialchars($booking['available_time']) ?></td>
            <td>₹<?= htmlspecialchars($booking['price']) ?></td>
            <td class="status-<?= strtolower($booking['status']) ?>">
                <?= htmlspecialchars($booking['status']) ?>
            </td>
        </tr>
    <?php endforeach; ?>
</tbody>

            </table>
        <?php else: ?>
            <p>You have not booked any events yet.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    $(document).ready(function(){
        function loadFilters() {
            $.ajax({
                url: "fetch_filters.php",
                type: "GET",
                dataType: "json",
                success: function(data) {
                    let categoryDropdown = $("#category_filter");
                    let venueDropdown = $("#venue_filter");

                    $.each(data.categories, function(index, category) {
                        categoryDropdown.append(`<option value="${category.id}">${category.name}</option>`);
                    });

                    $.each(data.venues, function(index, venue) {
                        venueDropdown.append(`<option value="${venue.id}">${venue.name}</option>`);
                    });
                }
            });
        }

        function loadEvents() {
            let filters = {
                event_name: $("#event_name_search").val(),
                category_id: $("#category_filter").val(),
                venue_id: $("#venue_filter").val(),
                event_date: $("#date_filter").val(),
                event_time: $("#time_filter").val()
            };

            $.ajax({
                url: "fetch_events.php",
                type: "POST",
                data: filters,
                success: function(data) {
                    $("#event_list").html(data);
                }
            });
        }

        loadFilters();
        loadEvents();

        $("#search_btn").click(loadEvents);
        $("#event_name_search").keyup(loadEvents);
    });

    window.addEventListener("pageshow", function (event) {
        if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
            window.location.reload();
        }
    });
</script>

</body>
</html>
