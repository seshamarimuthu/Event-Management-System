<?php
require_once 'razorpay-php/Razorpay.php';
use Razorpay\Api\Api;

$razorpayApiKey = 'rzp_test_ZSEAuP3Q29FzZq';
$razorpaySecret = 'jhuHUarLsN6dT9uuTQEG7tpG';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_id = $_POST['payment_id'];
    $order_id = $_POST['order_id'];
    $signature = $_POST['signature'];

    $api = new Api($razorpayApiKey, $razorpaySecret);

    $generated_signature = hash_hmac('sha256', $order_id . "|" . $payment_id, $razorpaySecret);

    if ($generated_signature === $signature) {
        include 'db.php';  
        $update_payment_sql = "UPDATE bookings SET payment_status = 'paid' WHERE order_id = '$order_id'";
        if ($conn->query($update_payment_sql)) {
            echo "Payment Verified Successfully";
        } else {
            echo "Failed to update payment status.";
        }
    } else {
        echo "Payment Verification Failed!";
    }
} else {
    echo "Invalid Request Method";
}
?>
