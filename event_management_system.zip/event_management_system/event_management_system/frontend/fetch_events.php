<?php
include '../db.php';

$event_name = $_POST['event_name'] ?? '';
$category_id = $_POST['category_id'] ?? '';
$venue_id = $_POST['venue_id'] ?? '';
$event_date = $_POST['event_date'] ?? '';
$event_time = $_POST['event_time'] ?? '';

$query = "SELECT events.id, events.name, events.description, events.slots, events.price, 
                 events.available_time, events.available_date, 
                 venues.name AS venue_name,
                 categories.name AS category_name 
          FROM events 
          JOIN categories ON events.category_id = categories.id 
          JOIN venues ON events.venue_id = venues.id 
          WHERE 1";

if (!empty($event_name)) {
    $query .= " AND events.name LIKE '%$event_name%'";
}
if (!empty($category_id)) {
    $query .= " AND events.category_id = '$category_id'";
}
if (!empty($venue_id)) {
    $query .= " AND events.venue_id = '$venue_id'";
}
if (!empty($event_date)) {
    $query .= " AND events.available_date = '$event_date'";
}
if (!empty($event_time)) {
    $query .= " AND events.available_time = '$event_time'";
}

$result = $conn->query($query);
?>

<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #f0f2f5;
        margin: 0;
        padding: 30px;
    }

    .event-container {
        max-width: 1200px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 20px;
    }

    .event-card {
        background: #fff;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: transform 0.2s;
    }

    .event-card:hover {
        transform: translateY(-4px);
    }

    .event-title {
        font-size: 20px;
        font-weight: 600;
        color: #222;
        margin-bottom: 8px;
    }

    .info {
        font-size: 14px;
        color: #555;
        margin: 4px 0;
    }

    .highlight {
        color: #28a745;
        font-weight: bold;
    }

    .slot-input {
        width: 70px;
        padding: 6px;
        margin-top: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }

    .price-total {
        margin-top: 10px;
        font-size: 15px;
    }

    .total-price {
        font-weight: bold;
        color: #e55353;
    }

    .book-btn {
        margin-top: 15px;
        padding: 10px 20px;
        background-color: #0069d9;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .book-btn:hover {
        background-color: #004aa4;
    }
    .category-tag {
    display: inline-block;
    font-size: 13px;
    color: #444;
    background-color: #e0e0e0;
    padding: 4px 10px;
    border-radius: 4px;
    margin-bottom: 10px;
    font-weight: 500;
}

</style>

<div class="event-container">
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $event_id = $row['id'];
        $price = $row['price'];
        $slots = $row['slots'];

        echo "
        <div class='event-card'>
            <div>
                <div class='event-title'>" . htmlspecialchars($row['name']) . "</div>
            <span class='category-tag'>{$row['category_name']}</span>


                <p class='info'><strong>Time:</strong> {$row['available_time']}</p>
                <p class='info'><strong>Venue:</strong> {$row['venue_name']}</p>
                <p class='info'><strong>Price per ticket:</strong> ₹<span class='price' data-price='{$price}'>{$price}</span></p>
                <p class='info'><strong>Slots available:</strong> <span class='highlight'>{$slots}</span></p>

                <label class='info'>Select Quantity:
                    <input type='number' class='slot-input' id='qty_{$event_id}' min='1' max='{$slots}' value='1' data-event-id='{$event_id}'>
                </label>

                <p class='price-total'>Total Price: ₹<span class='total-price'>{$price}</span></p>
            </div>
            <button class='book-btn' data-event-id='{$event_id}'>Book Now</button>
        </div>
        ";
    }
} else {
    echo "<p>No events found.</p>";
}
?>
</div>

<script>
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('slot-input')) {
            const input = e.target;
            const price = parseFloat(input.closest('.event-card').querySelector('.price').dataset.price);
            const quantity = parseInt(input.value) || 1;
            const total = price * quantity;
            input.closest('.event-card').querySelector('.total-price').textContent = total.toFixed(2);
        }
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('book-btn')) {
            const eventId = e.target.dataset.eventId;
            const qty = document.getElementById('qty_' + eventId).value;
            window.location.href = `book.php?id=${eventId}&qty=${qty}`;
        }
    });
</script>
