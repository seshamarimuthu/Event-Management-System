<?php
include '../db.php';

$event_name = isset($_POST['event_name']) ? $_POST['event_name'] : '';
$category_id = isset($_POST['category_id']) ? $_POST['category_id'] : '';
$venue_id = isset($_POST['venue_id']) ? $_POST['venue_id'] : '';
$event_date = isset($_POST['event_date']) ? $_POST['event_date'] : '';
$event_time = isset($_POST['event_time']) ? $_POST['event_time'] : '';

$query = "SELECT events.id, events.name, events.description, events.slots, events.price, 
                 events.available_time, events.available_date, 
                 venues.name AS venue_name,
                 categories.name AS category_name 
          FROM events 
          JOIN categories ON events.category_id = categories.id 
          JOIN venues ON events.venue_id = venues.id 
          WHERE 1";

if (!empty($event_name)) {
    $query .= " AND events.name LIKE '%$event_name%'";
}
if (!empty($category_id)) {
    $query .= " AND events.category_id = '$category_id'";
}
if (!empty($venue_id)) {
    $query .= " AND events.venue_id = '$venue_id'";
}
if (!empty($event_date)) {
    $query .= " AND events.available_date = '$event_date'";
}
if (!empty($event_time)) {
    $query .= " AND events.available_time = '$event_time'";
}

$result = $conn->query($query);
$output = "<ul>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $output .= "<li>
            <strong>" . htmlspecialchars($row['name']) . "</strong> 
            ({$row['category_name']}) - 
            {$row['venue_name']} - 
            Date: {$row['available_date']} - 
            Time: {$row['available_time']} - 
            <a href='book.php?id={$row['id']}'>Book</a>
        </li>";
    }
} else {
    $output .= "<li>No events found.</li>";
}

$output .= "</ul>";

echo $output;
?>
