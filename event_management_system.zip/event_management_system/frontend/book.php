<?php
session_start();
include '../db.php'; 
require '../phpmailer/src/PHPMailer.php';  
require '../phpmailer/src/Exception.php';
require '../phpmailer/src/SMTP.php';
require_once '../razorpay-php/Razorpay.php';  

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Razorpay\Api\Api;

if ($_SESSION['usertype'] !== 'customer') {
    header("Location: index.php");
    exit;
}


// Mailer credentials
$mailerEmail ='seshadhoni777@gmail.com'; 
$mailerPassword ='dgxa xfvu sdzh hulv';   
$mailerName = 'sesha';


$user_id = $_SESSION["user_id"];
$event_id = $_GET["id"];

$event_sql = "SELECT * FROM events WHERE id = $event_id";
$event_result = $conn->query($event_sql);
$event = $event_result->fetch_assoc();

if ($event['slots'] <= 0) {
    echo "<script>alert('Sorry, no available slots for this event.');window.location.href='book_ticket.php';</script>";
    exit;
}

$amount = $event['price'] * 100; 

$user_result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $user_result->fetch_assoc();
$user_email = $user['email'];

//Razorpay key
$razorpayApiKey = 'rzp_test_ZSEAuP3Q29FzZq';  
$razorpaySecret = 'jhuHUarLsN6dT9uuTQEG7tpG'; 

$api = new Api($razorpayApiKey, $razorpaySecret);

$orderData = [
    'receipt' => $user_id . '-' . $event_id,
    'amount' => $amount,  
    'currency' => 'INR',
    'payment_capture' => 1,
];

try {
    $razorpayOrder = $api->order->create($orderData);
    $orderId = $razorpayOrder->id; 
} catch (Exception $e) {
    die("Error creating Razorpay order: " . $e->getMessage());
}

$new_slots = $event['slots'] - 1;
$update_slots_sql = "UPDATE events SET slots = $new_slots WHERE id = $event_id";
$conn->query($update_slots_sql);

$sql = "INSERT INTO bookings (user_id, event_id, status, payment_status, order_id) VALUES ('$user_id', '$event_id', 'confirmed', 'pending', '$orderId')";
$conn->query($sql);

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $mailerEmail; 
    $mail->Password = $mailerPassword;   
    $mail->SMTPSecure = 'tls';   
    $mail->Port = 587;       
    $mail->setFrom($mailerEmail, $mailerName);
    $mail->addAddress($user_email);  
    $mail->isHTML(true);
    $mail->Subject = "Booking Confirmed for " . $event['name'];
    $mail->Body = "
        <h2>Booking Confirmed!</h2>
        <p>Thank you for booking <strong>{$event['name']}</strong></p>
        <p>Description: {$event['description']}</p>
        <p>Date: {$event['available_date']}</p>
        <p>Time: {$event['available_time']}</p>
        <p>Price: ₹{$event['price']}</p>
        <p>Status: <strong>Confirmed</strong></p>
        <p>Your order ID is: $orderId</p>
    ";

    $mail->send();  

    echo "
    <!-- Include Razorpay's Checkout Script -->
    <script src='https://checkout.razorpay.com/v1/checkout.js'></script>

    <script>
        var options = {
            'key': 'rzp_test_ZSEAuP3Q29FzZq',  // Your Razorpay API Key
            'amount': $amount,  // Amount in paise
            'currency': 'INR',  // Currency
            'order_id': '$orderId',  // Order ID created by Razorpay
            'name': 'Event Booking',  // Name of the event
            'description': 'Booking for {$event['name']}',  // Description
            'handler': function (response) {
                var payment_id = response.razorpay_payment_id;
                var order_id = response.razorpay_order_id;
                var signature = response.razorpay_signature;

                // Send the payment details to the backend for verification
                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'verify_payment.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        if (xhr.responseText === 'Payment Verified Successfully') {
                            window.location.href = 'payment_success.php?order_id=' + order_id;
                        } else {
                            alert('Payment Verification Failed!');
                            window.location.href = 'book_ticket.php'; // Redirect to book_ticket.php if verification fails
                        }
                    }
                };
                var data = 'payment_id=' + payment_id + '&order_id=' + order_id + '&signature=' + signature;
                xhr.send(data);
            },
            'prefill': {
                'name': '{$user['name']}',  // User's Name
                'email': '{$user['email']}'  // User's Email
            },
            'theme': {
                'color': '#F37254'
            },
            'modal': {
                'ondismiss': function() {
                    window.location.href = 'book_ticket.php'; // Redirect to book_ticket.php if payment modal is closed or dismissed
                }
            }
        };
        var rzp1 = new Razorpay(options);
        rzp1.open();
    </script>
    ";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
?>
