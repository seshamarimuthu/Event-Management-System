<?php
session_start();
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();
    if ($user && password_verify($password, hash: $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["usertype"] = $user["usertype"];
        $_SESSION["username"] = $user["name"];

        if ($user["usertype"] == "admin") {
            $_SESSION['admin_logged_in'] = true;
            header("Location:admin/admin.php");
            exit();
        } else {
            header("Location:frontend/book_ticket.php");
        }
        exit();
    } else {
        echo "
        <script>
            alert('Invalid credentials.');
            window.location.href = 'index.php'; 
        </script>
        ";
    }
    
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles/login.css">
</head>

<body>
    <div class="box">
        <h1>Login</h1>
        <form method="POST">
            <input class="input" type="email" name="email" placeholder="Email" required>
            <input class="input" type="password" name="password" placeholder="Password" required>
            <button class="signup-btn" type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</body>

</html>